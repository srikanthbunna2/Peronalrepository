package com.bankdhofar.crmnext.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;
/*
 * Purpose : To load the  external properties into the Broker
 */

public class PropertyManager {
	
	static Properties  prop = new Properties();
	static HashMap<String, String> hmp = null; 
	
	public static String getPropertyValue(String propertyName){
		
		if (hmp == null) {
			try {
				prop.load(new FileInputStream("/brokerProperties/middleware.properties"));
				String key = null;
				hmp = new HashMap<String, String>();
				Enumeration<Object> enumeration = prop.keys();
				while (enumeration.hasMoreElements()){
					key = (String)enumeration.nextElement();
					hmp.put(key, prop.get(key).toString());
				}
			}catch (FileNotFoundException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return hmp.get(propertyName) != null ? hmp.get(propertyName) : " ";
	}

	public static Boolean getAuditSwitch(String propertyName, String serviceName) {
		if (hmp == null) {
			try {
				prop.load(new FileInputStream("/brokerProperties/middleware.properties"));
				String key = null;
				hmp = new HashMap<String, String>();
				Enumeration enumeration = prop.keys();
				while (enumeration.hasMoreElements())
				{
					key =(String)enumeration.nextElement();
					hmp.put(key, prop.get(key).toString());
				}
			}catch (FileNotFoundException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		String serviceList = hmp.get(propertyName).toString();
		if (serviceList.contains(serviceName)) {
			return new Boolean(true);
		}else {
			return new Boolean(false);
		}
	}
	
}
