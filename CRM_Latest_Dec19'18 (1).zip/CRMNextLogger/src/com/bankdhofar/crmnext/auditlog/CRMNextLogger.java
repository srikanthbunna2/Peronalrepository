package com.bankdhofar.crmnext.auditlog;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**   This is the class to Log the log4j  audit logging 
 *   for Webservice channel. This implements Ilogger Interface.
 *   
 * 
 * */


public class CRMNextLogger implements Ilogger {

	//private instance which logs the messages
	private static Logger log = Logger.getLogger(CRMNextLogger.class);

	//This method loads the configuration information required for this channel
	public void configureLog4j(String channelName) {
		
		String fileName = "/brokerProperties/" + channelName + "_log4j.properties";
		//String fileName = "D:\\Jayaseelan\\IIB10_ALL_PROJECTS\\CRMNextLogger\\crmnext_log4j.properties";
		PropertyConfigurator.configure(fileName);
	}
	
	//logs debug messages
	public void logDebug(String logMessage) {
		log.debug(logMessage);
	}
	
	//logs error messages
	public void logError(String logMessage) {
	   log.error(logMessage);
	}
	
	//logs fatal messages
	public void logFatal(String logMessage) {
		log.fatal(logMessage);
	}
	
	//logs information messages
	public void logInfo(String logMessage) {
		log.info(logMessage);
	}
}
