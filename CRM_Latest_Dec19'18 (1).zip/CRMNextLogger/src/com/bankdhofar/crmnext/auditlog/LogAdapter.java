package com.bankdhofar.crmnext.auditlog;




/*
 * This is the class which interacts with the outside
 * (ESQL code) to log the messages to the appropriate
 * Log files in the respective directories configured
 * in the properties file.
 */

public class LogAdapter {
	
	//logs debug message
	public static void logDebug(String channelName,String logMessage) {
	    Ilogger iLogger = LogFactory.getLoggerInstance(channelName); 	
		iLogger.logDebug(logMessage);
	}
	
	//logs error messages
	public static void logError(String channelName,String logMessage) {
		Ilogger iLogger = LogFactory.getLoggerInstance(channelName); 	
		iLogger.logError(logMessage);
	}
	
	//logs fatal messages
	public static void logFatal(String channelName,String logMessage) {
		Ilogger iLogger = LogFactory.getLoggerInstance(channelName); 	
	    iLogger.logFatal(logMessage);	
	}
	
	//logs information messages.
	public static void logInfo(String channelName,String logMessage) {
	    Ilogger iLogger = LogFactory.getLoggerInstance(channelName); 
		iLogger.logInfo(logMessage);
	}
}
