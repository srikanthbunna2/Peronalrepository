package com.bankdhofar.crmnext.auditlog;


/*
 * This class is just a test class . This is 
 * just used for testing.
 */

public class TestLogger {
	public static void main(String[] args) {
		LogAdapter.logInfo("crmnext", "Test");
		System.out.println("End of Log");
	}
}
