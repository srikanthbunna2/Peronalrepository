package com.bankdhofar.crmnext.auditlog;



/**  
 *  This is the interface that all logging classes should implement.
 *  
 * */

public interface Ilogger {
	
	//This is commended
	public void configureLog4j(String channelName);
	public void logDebug(String logMessage);
	public void logInfo(String logMessage);
	public void logError(String logMessage);
	public void logFatal(String logMessage);
}
