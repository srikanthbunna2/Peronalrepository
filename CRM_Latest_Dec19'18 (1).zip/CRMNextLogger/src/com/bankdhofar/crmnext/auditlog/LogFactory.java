package com.bankdhofar.crmnext.auditlog;

import java.util.HashMap;



public class LogFactory {
	
	//hashmap to hold the logger instances
	
	static HashMap<String, Ilogger> hmpInst= new HashMap<String, Ilogger>();
	
	//this method is called by the log adapter class to get the
	//logger instance.
	public static Ilogger getLoggerInstance(String channelName){
		Ilogger  iLogger = null;
		try {
			
			//if the logger instance is created, they are retreived from
			//hash map and returned to the caller.
			if(hmpInst.get(channelName)!=null){
				iLogger = (Ilogger) hmpInst.get(channelName);
				iLogger.configureLog4j(channelName);
				return iLogger;
			}
            //if the logger instance is not created then a new
			//instance is created and placed in the hashmap.
			else{
				String className = getClassName(channelName);
				iLogger = (Ilogger) Class.forName(className).newInstance();	
				iLogger.configureLog4j(channelName);
				hmpInst.put(channelName, iLogger);
			}
		}
		
		catch (IllegalAccessException e) {
			System.out.println("Inside IllegalAccessException catch block...");
			e.printStackTrace();
		}
		
		catch (InstantiationException e) {
			System.out.println("Inside InstantiationException catch block...");
			e.printStackTrace();
		}
		
		catch (ClassNotFoundException e) {
			System.out.println("Inside ClassNotFoundException catch block...");
			e.printStackTrace();
		}
		
		return iLogger;
	}
	
	//this gives the current logger instance name.
	public static String getClassName(String channelName){
		return "com.bankdhofar.crmnext.auditlog."+(channelName.toUpperCase())+"Logger";
	}
}
